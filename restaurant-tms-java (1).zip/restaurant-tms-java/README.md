# TableMaster – Restaurant Table Management (Java / Spring Boot)
Spring Boot 3 + Thymeleaf + SQLite + Chart.js + Bootstrap 5. Requires JDK 17+ and Maven 3.8+ (or VS Code with the Java extension pack).

## Run
1. In this folder run:  `mvn spring-boot:run`
2. Open http://localhost:8080 and log in with **admin / admin123**.

Build a jar instead: `mvn package` then `java -jar target/table-management-1.0.jar`.
`restaurant.db` is created and seeded on first run; delete it to reset the data.
