document.addEventListener("DOMContentLoaded", () => {
  const sb = document.getElementById("sidebar");
  document.getElementById("toggle")?.addEventListener("click", () => sb.classList.toggle("open"));
  document.querySelector(".content")?.addEventListener("click", () => sb.classList.remove("open"));
  setTimeout(() => document.querySelectorAll(".auto-dismiss").forEach(a => bootstrap.Alert.getOrCreateInstance(a).close()), 5000);
  const modal = document.getElementById("deleteModal");
  document.querySelectorAll(".delete-btn").forEach(b => b.addEventListener("click", () => {
    document.getElementById("deleteForm").action = b.dataset.action;
    document.getElementById("deleteName").textContent = b.dataset.name;
    bootstrap.Modal.getOrCreateInstance(modal).show();
  }));
  document.querySelectorAll(".filter-form select").forEach(s => s.addEventListener("change", () => s.form.submit()));
  const sel = document.getElementById("tableSelect"), g = document.getElementById("guests"), hint = document.getElementById("capHint");
  if (sel && g) {
    const sync = () => { const c = sel.selectedOptions[0]?.dataset.cap; g.max = c || ""; hint.textContent = c ? `(max ${c})` : ""; };
    sel.addEventListener("change", sync); sync();
    // Smart suggestion: pick the smallest available table that fits the party
    g.addEventListener("input", () => {
      const n = parseInt(g.value); if (!n) return;
      let best = null;
      [...sel.options].forEach(o => { const c = +o.dataset.cap; if (c >= n && (!best || c < +best.dataset.cap)) best = o; });
      if (best) { sel.value = best.value; sync(); hint.textContent = `(best fit: ${best.text.split(" —")[0]}, max ${best.dataset.cap})`; }
      else { hint.textContent = "(no available table fits this party)"; }
    });
  }
});
