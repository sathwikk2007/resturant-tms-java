package com.restaurant;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class Web {
    static final List<String> STATUSES = List.of("Available", "Occupied", "Cleaning");
    static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private final JdbcTemplate db;

    Web(JdbcTemplate db) { this.db = db; }

    @ModelAttribute("path") String path(HttpServletRequest r) { return r.getRequestURI(); }
    static String now() { return LocalDateTime.now().format(FMT); }
    static Integer num(String s) { try { return Integer.parseInt(s.trim()); } catch (Exception e) { return null; } }

    List<Map<String, Object>> tables(String q, String status) {
        String sql = "SELECT t.*, a.customer_name, a.guests, a.seated_at FROM tables t LEFT JOIN assignments a ON a.table_id=t.id AND a.left_at IS NULL WHERE 1=1";
        List<Object> p = new ArrayList<>();
        if (q != null && !q.isBlank()) { sql += " AND CAST(t.number AS TEXT) LIKE ?"; p.add("%" + q.trim() + "%"); }
        if (status != null && STATUSES.contains(status)) { sql += " AND t.status=?"; p.add(status); }
        return db.queryForList(sql + " ORDER BY t.number", p.toArray());
    }

    Map<String, Object> table(int id) {
        List<Map<String, Object>> l = db.queryForList("SELECT * FROM tables WHERE id=?", id);
        return l.isEmpty() ? null : l.get(0);
    }

    // ---------- Login ----------
    @GetMapping("/login") String loginPage() { return "login"; }

    @PostMapping("/login")
    String login(@RequestParam String username, @RequestParam String password, HttpSession s, Model m, RedirectAttributes ra) {
        if ("admin".equals(username) && "admin123".equals(password)) {
            s.setAttribute("user", username);
            ra.addFlashAttribute("msg", "Welcome back! Login successful.");
            return "redirect:/";
        }
        m.addAttribute("err", "Invalid username or password.");
        return "login";
    }

    @GetMapping("/logout")
    String logout(HttpSession s, RedirectAttributes ra) {
        s.invalidate(); ra.addFlashAttribute("msg", "You have been logged out."); return "redirect:/login";
    }

    // ---------- Dashboard ----------
    @GetMapping("/")
    String dashboard(Model m) {
        Map<String, Integer> counts = new HashMap<>();
        STATUSES.forEach(x -> counts.put(x, 0));
        int total = 0;
        for (Map<String, Object> r : db.queryForList("SELECT status, COUNT(*) AS n FROM tables GROUP BY status")) {
            int n = ((Number) r.get("n")).intValue();
            counts.put((String) r.get("status"), n); total += n;
        }
        List<Map<String, Object>> ts = tables(null, null);
        int seatsTotal = 0, seated = 0;
        List<String> tl = new ArrayList<>();
        List<Integer> tc = new ArrayList<>(), tg = new ArrayList<>();
        for (Map<String, Object> t : ts) {
            int cap = ((Number) t.get("capacity")).intValue();
            int gs = t.get("guests") == null ? 0 : ((Number) t.get("guests")).intValue();
            seatsTotal += cap; seated += gs; tl.add("T" + t.get("number")); tc.add(cap); tg.add(gs);
        }
        List<String> hl = new ArrayList<>();
        List<Number> hg = new ArrayList<>();
        for (Map<String, Object> r : db.queryForList("SELECT substr(seated_at,12,2) AS h, SUM(guests) AS g FROM assignments GROUP BY h ORDER BY h")) {
            hl.add(r.get("h") + ":00"); hg.add((Number) r.get("g"));
        }
        Map<String, Object> day = db.queryForMap("SELECT COUNT(*) AS n, COALESCE(SUM(guests),0) AS g FROM assignments WHERE substr(seated_at,1,10)=?",
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        Double avg = db.queryForObject("SELECT AVG((julianday(left_at)-julianday(seated_at))*1440) FROM assignments WHERE left_at IS NOT NULL", Double.class);
        m.addAttribute("counts", counts); m.addAttribute("total", total); m.addAttribute("seats", seatsTotal);
        m.addAttribute("tables", ts); m.addAttribute("seated", seated);
        m.addAttribute("seatPct", seatsTotal == 0 ? 0 : seated * 100 / seatsTotal);
        m.addAttribute("occPct", total == 0 ? 0 : counts.get("Occupied") * 100 / total);
        m.addAttribute("servedParties", day.get("n")); m.addAttribute("servedGuests", day.get("g"));
        m.addAttribute("avgMins", avg == null ? 0 : Math.round(avg));
        m.addAttribute("statusData", List.of(counts.get("Available"), counts.get("Occupied"), counts.get("Cleaning")));
        m.addAttribute("hourLabels", hl); m.addAttribute("hourGuests", hg);
        m.addAttribute("tLabels", tl); m.addAttribute("tCap", tc); m.addAttribute("tGuests", tg);
        return "dashboard";
    }

    // ---------- Manage tables ----------
    @GetMapping("/tables")
    String list(@RequestParam(required = false) String q, @RequestParam(required = false) String status, Model m) {
        m.addAttribute("tables", tables(q, status)); m.addAttribute("q", q == null ? "" : q);
        m.addAttribute("status", status == null ? "" : status); m.addAttribute("statuses", STATUSES);
        return "tables";
    }

    String validate(Map<String, String> f, Integer id) {
        Integer n = num(f.get("number")), c = num(f.get("capacity"));
        if (n == null || n < 1) return "Table number must be a positive whole number.";
        if (c == null || c < 1 || c > 20) return "Seating capacity must be a whole number between 1 and 20.";
        if (!db.queryForList("SELECT id FROM tables WHERE number=? AND id<>?", n, id == null ? -1 : id).isEmpty())
            return "Table " + n + " already exists.";
        return null;
    }

    @GetMapping("/tables/add")
    String addForm(Model m) { m.addAttribute("table", new HashMap<>()); m.addAttribute("editing", false); return "table_form"; }

    @PostMapping("/tables/add")
    String add(@RequestParam Map<String, String> f, Model m, RedirectAttributes ra) {
        String err = validate(f, null);
        if (err != null) { m.addAttribute("err", err); m.addAttribute("table", f); m.addAttribute("editing", false); return "table_form"; }
        db.update("INSERT INTO tables(number,capacity) VALUES(?,?)", num(f.get("number")), num(f.get("capacity")));
        ra.addFlashAttribute("msg", "Table " + num(f.get("number")) + " added successfully.");
        return "redirect:/tables";
    }

    @GetMapping("/tables/{id}/edit")
    String editForm(@PathVariable int id, Model m, RedirectAttributes ra) {
        Map<String, Object> t = table(id);
        if (t == null) { ra.addFlashAttribute("err", "Table not found."); return "redirect:/tables"; }
        m.addAttribute("table", t); m.addAttribute("editing", true); m.addAttribute("tid", id);
        return "table_form";
    }

    @PostMapping("/tables/{id}/edit")
    String edit(@PathVariable int id, @RequestParam Map<String, String> f, Model m, RedirectAttributes ra) {
        Map<String, Object> t = table(id);
        if (t == null) { ra.addFlashAttribute("err", "Table not found."); return "redirect:/tables"; }
        String err = validate(f, id);
        if (err == null && "Occupied".equals(t.get("status"))) {
            List<Map<String, Object>> a = db.queryForList("SELECT guests FROM assignments WHERE table_id=? AND left_at IS NULL", id);
            if (!a.isEmpty() && num(f.get("capacity")) < ((Number) a.get(0).get("guests")).intValue())
                err = "Cannot reduce capacity below the " + a.get(0).get("guests") + " guests currently seated.";
        }
        if (err != null) { m.addAttribute("err", err); m.addAttribute("table", f); m.addAttribute("editing", true); m.addAttribute("tid", id); return "table_form"; }
        db.update("UPDATE tables SET number=?, capacity=? WHERE id=?", num(f.get("number")), num(f.get("capacity")), id);
        db.update("UPDATE assignments SET table_number=? WHERE table_id=?", num(f.get("number")), id);
        ra.addFlashAttribute("msg", "Table " + num(f.get("number")) + " updated successfully.");
        return "redirect:/tables";
    }

    @PostMapping("/tables/{id}/delete")
    String delete(@PathVariable int id, RedirectAttributes ra) {
        Map<String, Object> t = table(id);
        if (t == null) ra.addFlashAttribute("err", "Table not found.");
        else if ("Occupied".equals(t.get("status"))) ra.addFlashAttribute("err", "Table " + t.get("number") + " is occupied and cannot be deleted.");
        else { db.update("DELETE FROM tables WHERE id=?", id); ra.addFlashAttribute("msg", "Table " + t.get("number") + " deleted."); }
        return "redirect:/tables";
    }

    // ---------- Customer assignment ----------
    @GetMapping("/assign")
    String assignPage(Model m) { return assignView(m, new HashMap<>()); }

    String assignView(Model m, Map<String, String> form) {
        m.addAttribute("available", db.queryForList("SELECT * FROM tables WHERE status='Available' ORDER BY number"));
        m.addAttribute("form", form);
        return "assign";
    }

    @PostMapping("/assign")
    String assign(@RequestParam("customer_name") String name, @RequestParam String guests, @RequestParam("table_id") String tid,
                  Model m, RedirectAttributes ra) {
        name = name.trim();
        Integer g = num(guests), id = num(tid);
        Map<String, Object> t = id == null ? null : table(id);
        String err = null;
        if (name.length() < 2 || name.length() > 60) err = "Customer name must be 2-60 characters.";
        else if (g == null || g < 1) err = "Number of guests must be at least 1.";
        else if (t == null) err = "Please select a table.";
        else if (!"Available".equals(t.get("status"))) err = "Table " + t.get("number") + " is " + t.get("status") + " and cannot be assigned.";
        else if (g > ((Number) t.get("capacity")).intValue()) err = "Table " + t.get("number") + " seats only " + t.get("capacity") + " guests (you entered " + g + ").";
        if (err != null) {
            m.addAttribute("err", err);
            Map<String, String> form = new HashMap<>(Map.of("customer_name", name, "guests", guests, "table_id", tid));
            return assignView(m, form);
        }
        db.update("INSERT INTO assignments(table_id,table_number,customer_name,guests,seated_at) VALUES(?,?,?,?,?)", id, t.get("number"), name, g, now());
        db.update("UPDATE tables SET status='Occupied' WHERE id=?", id);
        ra.addFlashAttribute("msg", name + " (" + g + " guests) assigned to Table " + t.get("number") + ".");
        return "redirect:/assign";
    }

    // ---------- Status management ----------
    @GetMapping("/status")
    String statusPage(@RequestParam(required = false) String q, @RequestParam(required = false) String status, Model m) {
        m.addAttribute("tables", tables(q, status)); m.addAttribute("q", q == null ? "" : q);
        m.addAttribute("status", status == null ? "" : status); m.addAttribute("statuses", STATUSES);
        return "status";
    }

    @PostMapping("/status/{id}")
    String updateStatus(@PathVariable int id, @RequestParam String status, @RequestParam(required = false) String back, RedirectAttributes ra) {
        Map<String, Object> t = table(id);
        if (t == null || !STATUSES.contains(status)) ra.addFlashAttribute("err", "Invalid request.");
        else if (status.equals("Occupied")) ra.addFlashAttribute("err", "Use Customer Assignment to occupy a table.");
        else if (status.equals(t.get("status"))) ra.addFlashAttribute("err", "Table " + t.get("number") + " is already " + status + ".");
        else if ("Occupied".equals(t.get("status")) && status.equals("Available")) ra.addFlashAttribute("err", "An occupied table must go to Cleaning first.");
        else {
            if ("Occupied".equals(t.get("status")))
                db.update("UPDATE assignments SET left_at=? WHERE table_id=? AND left_at IS NULL", now(), id);
            db.update("UPDATE tables SET status=? WHERE id=?", status, id);
            ra.addFlashAttribute("msg", "Table " + t.get("number") + " is now " + status + ".");
        }
        return "/".equals(back) ? "redirect:/" : "redirect:/status";
    }

    // ---------- History ----------
    List<Map<String, Object>> historyRows(String q) {
        String sql = "SELECT *, CASE WHEN left_at IS NULL THEN NULL ELSE CAST(ROUND((julianday(left_at)-julianday(seated_at))*1440) AS INTEGER) END AS mins FROM assignments";
        List<Object> p = new ArrayList<>();
        if (q != null && !q.isBlank()) { sql += " WHERE customer_name LIKE ? OR CAST(table_number AS TEXT)=?"; p.add("%" + q.trim() + "%"); p.add(q.trim()); }
        return db.queryForList(sql + " ORDER BY seated_at DESC", p.toArray());
    }

    @GetMapping("/history")
    String history(@RequestParam(required = false) String q, Model m) {
        m.addAttribute("rows", historyRows(q));
        m.addAttribute("q", q == null ? "" : q);
        return "history";
    }

    static String csv(Object o) { return o == null ? "" : "\"" + o.toString().replace("\"", "\"\"") + "\""; }

    @GetMapping("/history/export")
    org.springframework.http.ResponseEntity<String> export(@RequestParam(required = false) String q) {
        StringBuilder sb = new StringBuilder("Customer,Table,Guests,Seated,Left,Minutes\n");
        for (Map<String, Object> r : historyRows(q))
            sb.append(csv(r.get("customer_name"))).append(',').append(r.get("table_number")).append(',').append(r.get("guests")).append(',')
              .append(csv(r.get("seated_at"))).append(',').append(csv(r.get("left_at"))).append(',').append(r.get("mins") == null ? "" : r.get("mins")).append('\n');
        return org.springframework.http.ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=assignment-history.csv")
                .contentType(new org.springframework.http.MediaType("text", "csv", java.nio.charset.StandardCharsets.UTF_8))
                .body(sb.toString());
    }
}
