package com.restaurant;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
public class App {
    public static void main(String[] args) { SpringApplication.run(App.class, args); }

    /** Creates the SQLite schema and seeds sample data on first run. */
    @Bean
    CommandLineRunner initDb(JdbcTemplate db) {
        return args -> {
            db.execute("CREATE TABLE IF NOT EXISTS tables(id INTEGER PRIMARY KEY AUTOINCREMENT, number INTEGER UNIQUE NOT NULL, capacity INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'Available')");
            db.execute("CREATE TABLE IF NOT EXISTS assignments(id INTEGER PRIMARY KEY AUTOINCREMENT, table_id INTEGER, table_number INTEGER NOT NULL, customer_name TEXT NOT NULL, guests INTEGER NOT NULL, seated_at TEXT NOT NULL, left_at TEXT)");
            Integer n = db.queryForObject("SELECT COUNT(*) FROM tables", Integer.class);
            if (n != null && n > 0) return;
            int[] caps = {2, 2, 4, 4, 4, 6, 6, 8, 2, 10};
            String[] st = {"Occupied", "Available", "Occupied", "Cleaning", "Available", "Occupied", "Available", "Available", "Cleaning", "Available"};
            for (int i = 0; i < 10; i++)
                db.update("INSERT INTO tables(number,capacity,status) VALUES(?,?,?)", i + 1, caps[i], st[i]);
            Object[][] rows = {
                {1, 1, "Priya Sharma", 2, 40, 0}, {3, 3, "Rahul Verma", 4, 25, 0}, {6, 6, "Anita Rao & Family", 5, 55, 0},
                {4, 4, "Kiran Kumar", 3, 150, 60}, {9, 9, "Sneha Reddy", 2, 200, 120},
                {2, 2, "Arjun Mehta", 2, 300, 210}, {8, 8, "Office Lunch Group", 7, 400, 280}};
            DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            for (Object[] r : rows) {
                LocalDateTime seated = LocalDateTime.now().minusMinutes((int) r[4]);
                int dur = (int) r[5];
                db.update("INSERT INTO assignments(table_id,table_number,customer_name,guests,seated_at,left_at) VALUES(?,?,?,?,?,?)",
                        r[0], r[1], r[2], r[3], seated.format(f), dur == 0 ? null : seated.plusMinutes(dur).format(f));
            }
        };
    }

    /** Redirects to /login when staff are not signed in. */
    @Configuration
    static class WebConfig implements WebMvcConfigurer {
        @Override
        public void addInterceptors(InterceptorRegistry reg) {
            reg.addInterceptor(new HandlerInterceptor() {
                @Override
                public boolean preHandle(HttpServletRequest q, HttpServletResponse s, Object h) throws Exception {
                    if (q.getSession().getAttribute("user") == null) { s.sendRedirect("/login"); return false; }
                    return true;
                }
            }).excludePathPatterns("/login", "/css/**", "/js/**", "/error");
        }
    }
}
